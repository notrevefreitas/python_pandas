import requests as req

# 3477
# id_sp = 3477
# id_recife = 7140
# id_fortaleza = 8050
region = "forecast/region/:{1}?token={0}"


def recovery_local(s, c, t):
    url = "http://apiadvisor.climatempo.com.br/api/v1/locale/city?name={1}&state={2}&token={0}".format(t, c, s)
    response = req.api.get(url).json()
    if len(response) == 0:
        return ''
    return response[0]["id"]


def recovery_weather_local(b_local, t):
    url = 'http://apiadvisor.climatempo.com.br/api/v1/weather/locale/{1}/current?token={0}'.format(t, b_local)
    response = req.api.get(url).json()
    print("Cidade:", response["name"])
    print("Temperatura:", response['data']['temperature'])
    x = ''' Cidade: {0}, Temperatura:  {1}'''.format(response["name"], response['data']['temperature'])
    return x


def recovery_d15_weather_local(b_local, t):
    url = 'http://apiadvisor.climatempo.com.br/api/v1/forecast/locale/{1}/days/15?token={0}'.format(t, b_local)
    response = req.api.get(url).json()
    lista = []
    for row in response['data']:
        dic = {}
        print('Sensacao Thermica com minima de ', row['thermal_sensation']['min'], 'e maxima de ',
              row['thermal_sensation']['max'], 'no dia:', row['date_br'])
        dic.update(
            {'max': row['thermal_sensation']['max'], 'min': row['thermal_sensation']['min'], 'date': row['date_br']})
        lista.append(dic)
    return lista


def recovery_h72_weather_local(b_local, t):
    url = 'http://apiadvisor.climatempo.com.br/api/v1/forecast/locale/{1}/hours/72?token={0}'.format(t, b_local)
    print(url)
    response = req.api.get(url).json()
    print(response)
    lista = []
    for row in response['data']:
        dic = {}
        print('Data {0} com temperatura {1} com precipitacao {2}'.format(row['date_br'],
                                                                         row['temperature']['temperature'],
                                                                         row['rain']['precipitation']))
        dic.update(
            {'precipitacao': row['rain']['precipitation'], 'temperatura': row['temperature']['temperature'],
             'date': row['date_br']})
        lista.append(dic)
    return lista


while True:
    token = 'fdc114cf7aaab2aa6a554e0316bb9fb2'
    state = input('Qual Estado Deseja Verificar a Temperatura:')
    if state is None or state == '':
        print('Digite um Estado')
        break
    city = input('Qual Cidade Deseja Verificar a Temperatura:')
    if city is None or city == '':
        print('Digite um Estado')
        break
    temp = input('Digite um dos valores para escolher a previsao: 1 - Atual, 2 - 15 dias, 3 - 72 horas')
    if temp is None:
        temp = 1
    id_local = recovery_local(state, city, token)
    if id_local == '':
        print('Tente Outro Lugar')
        break
    if temp == '1':
        recovery_weather_local(id_local, token)
        break
    elif temp == '2':
        recovery_d15_weather_local(id_local, token)
        break
    elif temp == '3':
        recovery_h72_weather_local(id_local, token)
        break