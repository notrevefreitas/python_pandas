from selenium import webdriver



from selenium import webdriver
from selenium.webdriver.common.keys import Keys 

driver = webdriver.Chrome()
driver.get('https://outlook.live.com/owa/?nlp=1"')
pesquisa = driver.find_element_by_id("i0116")
pesquisa.clear()
pesquisa.send_keys("notreve_113@hotmail.com")
click = driver.find_element_by_id("idSIButton9")
