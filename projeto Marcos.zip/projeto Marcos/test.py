'''seq = [1,2,3,4, 5,6,7,8]
def minha_casa(quarto):
    return quarto**2
minha_casa(4)

a = list(map(minha_casa,seq))

print(a)'''

foods = "bacon, meat, pork chop, landjaeger, hamburger"
food_arr = []
 

#print("old:{0}".format(foods.split(",")))
 
#print(foods.split(","))


#planeta = "terra "
#casal = "completa"
 

#print ("Dia que o planeta {0} está cheio de {1}".format("terra","completo"))

 
#Final Step: Printing result...
#print("new:\t{0}".format())
#print('{0} and {1}'.format('spam', 'eggs'))


def obterDominio(email):
    saida = email.split("@")[-1]
    return saida
print(obterDominio("everton@hotmail.com"))


def encontrarCachorro(string):
    return "cachorro" in string.lower()

print(encontrarCachorro("meu cachorro e top! "))
def contacahorro(string):
    return string 


def contaPalavra(string):
    a = 0
    for i in string.lower().split():
      if i =="cachorro": 
        a = a +1
        
        return a
contaPalavra("cachorro comeu a comida de outro cachorro ")


def internet(speed,browser ):

    if browser:
        speed = speed - 15
    if speed > 80:
        return "multa alta "
    if speed < 60:
        return "multa pequena"
    else :
        return "multa media "
print(internet(100,True ))


